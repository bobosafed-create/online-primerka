# -*- coding: utf-8 -*-
from yookassa.domain.common.payment_method_type import PaymentMethodType
from yookassa.domain.models.payment_data.payment_data import ResponsePaymentData
from yookassa.domain.models.payment_data.response.credit_card import CreditCard


class PaymentDataBankCard(ResponsePaymentData):
    """
    Оплата банковской картой.
    """  # noqa: E501

    __card = None
    """Данные банковской карты."""  # noqa: E501

    def __init__(self, *args, **kwargs):
        super(PaymentDataBankCard, self).__init__(*args, **kwargs)
        if self.type is None or self.type is not PaymentMethodType.BANK_CARD:
            self.type = PaymentMethodType.BANK_CARD

    @property
    def card(self):
        """
        Возвращает card модели PaymentDataBankCard.

        :return: card модели PaymentDataBankCard.
        :rtype: CreditCard
        """
        return self.__card

    @card.setter
    def card(self, value):
        """
        Устанавливает card модели PaymentDataBankCard.

        :param value: card модели PaymentDataBankCard.
        :type value: CreditCard
        """
        if isinstance(value, dict):
            self.__card = CreditCard(value)
        elif isinstance(value, CreditCard):
            self.__card = value
        else:
            raise TypeError('Invalid card value type in PaymentDataBankCard')

